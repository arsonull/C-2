﻿namespace HeroMaker
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.nameBox = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.supSpdBox = new System.Windows.Forms.CheckBox();
            this.timeBox = new System.Windows.Forms.CheckBox();
            this.gravBox = new System.Windows.Forms.CheckBox();
            this.teleBox = new System.Windows.Forms.CheckBox();
            this.supIntBox = new System.Windows.Forms.CheckBox();
            this.godBox = new System.Windows.Forms.CheckBox();
            this.boomBox = new System.Windows.Forms.CheckBox();
            this.eleBox = new System.Windows.Forms.CheckBox();
            this.psyBox = new System.Windows.Forms.CheckBox();
            this.auraBox = new System.Windows.Forms.CheckBox();
            this.supStrBox = new System.Windows.Forms.CheckBox();
            this.flyBox = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.controlPicker = new System.Windows.Forms.DateTimePicker();
            this.awareBox = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.bDayPicker = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.originBox = new System.Windows.Forms.ListBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.privTrans = new System.Windows.Forms.RadioButton();
            this.powerTrans = new System.Windows.Forms.RadioButton();
            this.publicTrans = new System.Windows.Forms.RadioButton();
            this.Alignment1 = new System.Windows.Forms.TrackBar();
            this.label6 = new System.Windows.Forms.Label();
            this.Alignment2 = new System.Windows.Forms.TrackBar();
            this.AlignmentTip = new System.Windows.Forms.ToolTip(this.components);
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.chaStat = new System.Windows.Forms.NumericUpDown();
            this.wisStat = new System.Windows.Forms.NumericUpDown();
            this.intStat = new System.Windows.Forms.NumericUpDown();
            this.conStat = new System.Windows.Forms.NumericUpDown();
            this.dexStat = new System.Windows.Forms.NumericUpDown();
            this.strStat = new System.Windows.Forms.NumericUpDown();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.descBox = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Alignment1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Alignment2)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chaStat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.wisStat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.intStat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.conStat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dexStat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.strStat)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(28, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(141, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Hero\'s Name:";
            // 
            // nameBox
            // 
            this.nameBox.Location = new System.Drawing.Point(176, 13);
            this.nameBox.Name = "nameBox";
            this.nameBox.Size = new System.Drawing.Size(177, 31);
            this.nameBox.TabIndex = 1;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.supSpdBox);
            this.groupBox1.Controls.Add(this.timeBox);
            this.groupBox1.Controls.Add(this.gravBox);
            this.groupBox1.Controls.Add(this.teleBox);
            this.groupBox1.Controls.Add(this.supIntBox);
            this.groupBox1.Controls.Add(this.godBox);
            this.groupBox1.Controls.Add(this.boomBox);
            this.groupBox1.Controls.Add(this.eleBox);
            this.groupBox1.Controls.Add(this.psyBox);
            this.groupBox1.Controls.Add(this.auraBox);
            this.groupBox1.Controls.Add(this.supStrBox);
            this.groupBox1.Controls.Add(this.flyBox);
            this.groupBox1.Location = new System.Drawing.Point(13, 73);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(435, 379);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Super Abilities";
            // 
            // supSpdBox
            // 
            this.supSpdBox.AutoSize = true;
            this.supSpdBox.Location = new System.Drawing.Point(224, 325);
            this.supSpdBox.Name = "supSpdBox";
            this.supSpdBox.Size = new System.Drawing.Size(169, 29);
            this.supSpdBox.TabIndex = 11;
            this.supSpdBox.Text = "Super Speed";
            this.supSpdBox.UseVisualStyleBackColor = true;
            // 
            // timeBox
            // 
            this.timeBox.AutoSize = true;
            this.timeBox.Location = new System.Drawing.Point(7, 325);
            this.timeBox.Name = "timeBox";
            this.timeBox.Size = new System.Drawing.Size(91, 29);
            this.timeBox.TabIndex = 10;
            this.timeBox.Text = "Time";
            this.timeBox.UseVisualStyleBackColor = true;
            // 
            // gravBox
            // 
            this.gravBox.AutoSize = true;
            this.gravBox.Location = new System.Drawing.Point(224, 270);
            this.gravBox.Name = "gravBox";
            this.gravBox.Size = new System.Drawing.Size(112, 29);
            this.gravBox.TabIndex = 9;
            this.gravBox.Text = "Gravity";
            this.gravBox.UseVisualStyleBackColor = true;
            // 
            // teleBox
            // 
            this.teleBox.AutoSize = true;
            this.teleBox.Location = new System.Drawing.Point(7, 270);
            this.teleBox.Name = "teleBox";
            this.teleBox.Size = new System.Drawing.Size(170, 29);
            this.teleBox.TabIndex = 8;
            this.teleBox.Text = "Teleportation";
            this.teleBox.UseVisualStyleBackColor = true;
            // 
            // supIntBox
            // 
            this.supIntBox.AutoSize = true;
            this.supIntBox.Location = new System.Drawing.Point(224, 215);
            this.supIntBox.Name = "supIntBox";
            this.supIntBox.Size = new System.Drawing.Size(181, 29);
            this.supIntBox.TabIndex = 7;
            this.supIntBox.Text = "Super Intellect";
            this.supIntBox.UseVisualStyleBackColor = true;
            // 
            // godBox
            // 
            this.godBox.AutoSize = true;
            this.godBox.Location = new System.Drawing.Point(7, 215);
            this.godBox.Name = "godBox";
            this.godBox.Size = new System.Drawing.Size(125, 29);
            this.godBox.TabIndex = 6;
            this.godBox.Text = "Creation";
            this.godBox.UseVisualStyleBackColor = true;
            // 
            // boomBox
            // 
            this.boomBox.AutoSize = true;
            this.boomBox.Location = new System.Drawing.Point(224, 160);
            this.boomBox.Name = "boomBox";
            this.boomBox.Size = new System.Drawing.Size(149, 29);
            this.boomBox.TabIndex = 5;
            this.boomBox.Text = "Explosions";
            this.boomBox.UseVisualStyleBackColor = true;
            // 
            // eleBox
            // 
            this.eleBox.AutoSize = true;
            this.eleBox.Location = new System.Drawing.Point(7, 160);
            this.eleBox.Name = "eleBox";
            this.eleBox.Size = new System.Drawing.Size(161, 29);
            this.eleBox.TabIndex = 4;
            this.eleBox.Text = "Elementalist";
            this.eleBox.UseVisualStyleBackColor = true;
            // 
            // psyBox
            // 
            this.psyBox.AutoSize = true;
            this.psyBox.Location = new System.Drawing.Point(224, 102);
            this.psyBox.Name = "psyBox";
            this.psyBox.Size = new System.Drawing.Size(196, 29);
            this.psyBox.TabIndex = 3;
            this.psyBox.Text = "Psychic Powers";
            this.psyBox.UseVisualStyleBackColor = true;
            // 
            // auraBox
            // 
            this.auraBox.AutoSize = true;
            this.auraBox.Location = new System.Drawing.Point(7, 102);
            this.auraBox.Name = "auraBox";
            this.auraBox.Size = new System.Drawing.Size(156, 29);
            this.auraBox.TabIndex = 2;
            this.auraBox.Text = "Aura Sense";
            this.auraBox.UseVisualStyleBackColor = true;
            // 
            // supStrBox
            // 
            this.supStrBox.AutoSize = true;
            this.supStrBox.Location = new System.Drawing.Point(224, 48);
            this.supStrBox.Name = "supStrBox";
            this.supStrBox.Size = new System.Drawing.Size(188, 29);
            this.supStrBox.TabIndex = 1;
            this.supStrBox.Text = "Super Strength";
            this.supStrBox.UseVisualStyleBackColor = true;
            // 
            // flyBox
            // 
            this.flyBox.AutoSize = true;
            this.flyBox.Location = new System.Drawing.Point(7, 48);
            this.flyBox.Name = "flyBox";
            this.flyBox.Size = new System.Drawing.Size(102, 29);
            this.flyBox.TabIndex = 0;
            this.flyBox.Text = "Flying";
            this.flyBox.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.controlPicker);
            this.groupBox2.Controls.Add(this.awareBox);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.bDayPicker);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Location = new System.Drawing.Point(541, 73);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(463, 379);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Important Dates";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 264);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(199, 25);
            this.label4.TabIndex = 5;
            this.label4.Text = "Control Over Power";
            // 
            // controlPicker
            // 
            this.controlPicker.Location = new System.Drawing.Point(9, 292);
            this.controlPicker.Name = "controlPicker";
            this.controlPicker.Size = new System.Drawing.Size(417, 31);
            this.controlPicker.TabIndex = 4;
            // 
            // awareBox
            // 
            this.awareBox.Location = new System.Drawing.Point(12, 183);
            this.awareBox.Name = "awareBox";
            this.awareBox.Size = new System.Drawing.Size(414, 31);
            this.awareBox.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 155);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(202, 25);
            this.label3.TabIndex = 2;
            this.label3.Text = "Super Power Found";
            // 
            // bDayPicker
            // 
            this.bDayPicker.Location = new System.Drawing.Point(12, 79);
            this.bDayPicker.Name = "bDayPicker";
            this.bDayPicker.Size = new System.Drawing.Size(414, 31);
            this.bDayPicker.TabIndex = 1;
            this.bDayPicker.Value = new System.DateTime(2020, 2, 25, 0, 0, 0, 0);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(91, 25);
            this.label2.TabIndex = 0;
            this.label2.Text = "Birthday";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(20, 497);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(174, 25);
            this.label5.TabIndex = 4;
            this.label5.Text = "Country of Origin";
            // 
            // originBox
            // 
            this.originBox.FormattingEnabled = true;
            this.originBox.ItemHeight = 25;
            this.originBox.Items.AddRange(new object[] {
            "North America",
            "South America",
            "Asia",
            "Australia",
            "Africa",
            "Antarctica",
            "Europe"});
            this.originBox.Location = new System.Drawing.Point(20, 525);
            this.originBox.Name = "originBox";
            this.originBox.Size = new System.Drawing.Size(204, 179);
            this.originBox.TabIndex = 5;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.privTrans);
            this.groupBox3.Controls.Add(this.powerTrans);
            this.groupBox3.Controls.Add(this.publicTrans);
            this.groupBox3.Location = new System.Drawing.Point(278, 497);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(261, 207);
            this.groupBox3.TabIndex = 6;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Favored Transportation";
            // 
            // privTrans
            // 
            this.privTrans.AutoSize = true;
            this.privTrans.Location = new System.Drawing.Point(7, 157);
            this.privTrans.Name = "privTrans";
            this.privTrans.Size = new System.Drawing.Size(208, 29);
            this.privTrans.TabIndex = 2;
            this.privTrans.TabStop = true;
            this.privTrans.Text = "Private Transport";
            this.privTrans.UseVisualStyleBackColor = true;
            // 
            // powerTrans
            // 
            this.powerTrans.AutoSize = true;
            this.powerTrans.Location = new System.Drawing.Point(7, 99);
            this.powerTrans.Name = "powerTrans";
            this.powerTrans.Size = new System.Drawing.Size(179, 29);
            this.powerTrans.TabIndex = 1;
            this.powerTrans.TabStop = true;
            this.powerTrans.Text = "Using Abilities";
            this.powerTrans.UseVisualStyleBackColor = true;
            // 
            // publicTrans
            // 
            this.publicTrans.AutoSize = true;
            this.publicTrans.Location = new System.Drawing.Point(7, 41);
            this.publicTrans.Name = "publicTrans";
            this.publicTrans.Size = new System.Drawing.Size(200, 29);
            this.publicTrans.TabIndex = 0;
            this.publicTrans.TabStop = true;
            this.publicTrans.Text = "Public Transport";
            this.publicTrans.UseVisualStyleBackColor = true;
            // 
            // Alignment1
            // 
            this.Alignment1.LargeChange = 1;
            this.Alignment1.Location = new System.Drawing.Point(567, 535);
            this.Alignment1.Maximum = 3;
            this.Alignment1.Minimum = 1;
            this.Alignment1.Name = "Alignment1";
            this.Alignment1.Size = new System.Drawing.Size(400, 90);
            this.Alignment1.TabIndex = 1;
            this.AlignmentTip.SetToolTip(this.Alignment1, "Lawful - Neutral - Chaotic");
            this.Alignment1.Value = 2;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(713, 497);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(107, 25);
            this.label6.TabIndex = 8;
            this.label6.Text = "Alignment";
            // 
            // Alignment2
            // 
            this.Alignment2.LargeChange = 1;
            this.Alignment2.Location = new System.Drawing.Point(567, 614);
            this.Alignment2.Maximum = 3;
            this.Alignment2.Minimum = 1;
            this.Alignment2.Name = "Alignment2";
            this.Alignment2.Size = new System.Drawing.Size(400, 90);
            this.Alignment2.TabIndex = 1;
            this.AlignmentTip.SetToolTip(this.Alignment2, "Good - Neutral - Evil");
            this.Alignment2.Value = 2;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(9, 27);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(39, 25);
            this.label7.TabIndex = 10;
            this.label7.Text = "Str";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(170, 27);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(50, 25);
            this.label8.TabIndex = 11;
            this.label8.Text = "Dex";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.chaStat);
            this.groupBox4.Controls.Add(this.wisStat);
            this.groupBox4.Controls.Add(this.intStat);
            this.groupBox4.Controls.Add(this.conStat);
            this.groupBox4.Controls.Add(this.dexStat);
            this.groupBox4.Controls.Add(this.strStat);
            this.groupBox4.Controls.Add(this.label12);
            this.groupBox4.Controls.Add(this.label11);
            this.groupBox4.Controls.Add(this.label10);
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Location = new System.Drawing.Point(19, 725);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(303, 204);
            this.groupBox4.TabIndex = 12;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Stats";
            // 
            // chaStat
            // 
            this.chaStat.Location = new System.Drawing.Point(219, 151);
            this.chaStat.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.chaStat.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.chaStat.Name = "chaStat";
            this.chaStat.Size = new System.Drawing.Size(78, 31);
            this.chaStat.TabIndex = 21;
            this.chaStat.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // wisStat
            // 
            this.wisStat.Location = new System.Drawing.Point(66, 151);
            this.wisStat.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.wisStat.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.wisStat.Name = "wisStat";
            this.wisStat.Size = new System.Drawing.Size(78, 31);
            this.wisStat.TabIndex = 20;
            this.wisStat.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // intStat
            // 
            this.intStat.Location = new System.Drawing.Point(219, 90);
            this.intStat.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.intStat.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.intStat.Name = "intStat";
            this.intStat.Size = new System.Drawing.Size(78, 31);
            this.intStat.TabIndex = 19;
            this.intStat.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // conStat
            // 
            this.conStat.Location = new System.Drawing.Point(66, 90);
            this.conStat.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.conStat.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.conStat.Name = "conStat";
            this.conStat.Size = new System.Drawing.Size(78, 31);
            this.conStat.TabIndex = 18;
            this.conStat.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // dexStat
            // 
            this.dexStat.Location = new System.Drawing.Point(219, 27);
            this.dexStat.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.dexStat.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.dexStat.Name = "dexStat";
            this.dexStat.Size = new System.Drawing.Size(78, 31);
            this.dexStat.TabIndex = 17;
            this.dexStat.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // strStat
            // 
            this.strStat.Location = new System.Drawing.Point(66, 27);
            this.strStat.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.strStat.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.strStat.Name = "strStat";
            this.strStat.Size = new System.Drawing.Size(78, 31);
            this.strStat.TabIndex = 16;
            this.strStat.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(170, 153);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(51, 25);
            this.label12.TabIndex = 15;
            this.label12.Text = "Cha";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(9, 153);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(48, 25);
            this.label11.TabIndex = 14;
            this.label11.Text = "Wis";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(170, 90);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(35, 25);
            this.label10.TabIndex = 13;
            this.label10.Text = "Int";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(9, 90);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(51, 25);
            this.label9.TabIndex = 12;
            this.label9.Text = "Con";
            // 
            // descBox
            // 
            this.descBox.Location = new System.Drawing.Point(364, 739);
            this.descBox.Multiline = true;
            this.descBox.Name = "descBox";
            this.descBox.Size = new System.Drawing.Size(410, 197);
            this.descBox.TabIndex = 13;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(364, 711);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(120, 25);
            this.label13.TabIndex = 14;
            this.label13.Text = "Description";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(813, 739);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(176, 197);
            this.button1.TabIndex = 15;
            this.button1.Text = "Create Hero!!";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1016, 973);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.descBox);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.Alignment2);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.Alignment1);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.originBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.nameBox);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Alignment1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Alignment2)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chaStat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.wisStat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.intStat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.conStat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dexStat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.strStat)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox nameBox;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox supSpdBox;
        private System.Windows.Forms.CheckBox timeBox;
        private System.Windows.Forms.CheckBox gravBox;
        private System.Windows.Forms.CheckBox teleBox;
        private System.Windows.Forms.CheckBox supIntBox;
        private System.Windows.Forms.CheckBox godBox;
        private System.Windows.Forms.CheckBox boomBox;
        private System.Windows.Forms.CheckBox eleBox;
        private System.Windows.Forms.CheckBox psyBox;
        private System.Windows.Forms.CheckBox auraBox;
        private System.Windows.Forms.CheckBox supStrBox;
        private System.Windows.Forms.CheckBox flyBox;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker controlPicker;
        private System.Windows.Forms.DateTimePicker awareBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker bDayPicker;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ListBox originBox;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton privTrans;
        private System.Windows.Forms.RadioButton powerTrans;
        private System.Windows.Forms.RadioButton publicTrans;
        private System.Windows.Forms.TrackBar Alignment1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TrackBar Alignment2;
        private System.Windows.Forms.ToolTip AlignmentTip;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.NumericUpDown chaStat;
        private System.Windows.Forms.NumericUpDown wisStat;
        private System.Windows.Forms.NumericUpDown intStat;
        private System.Windows.Forms.NumericUpDown conStat;
        private System.Windows.Forms.NumericUpDown dexStat;
        private System.Windows.Forms.NumericUpDown strStat;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox descBox;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button button1;
    }
}

